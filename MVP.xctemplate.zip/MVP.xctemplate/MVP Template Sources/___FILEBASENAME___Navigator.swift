//  ___FILEHEADER___

import UIKit

struct ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_productName___Contract.Navigator, AlertNavigator {
    unowned var viewController: UIViewController
}

extension ___FILEBASENAMEASIDENTIFIER___ {
   
}
