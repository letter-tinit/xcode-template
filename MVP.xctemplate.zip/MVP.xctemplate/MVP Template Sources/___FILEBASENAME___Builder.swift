//  ___FILEHEADER___

import UIKit

struct ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_productName___Contract.Builder {

}
