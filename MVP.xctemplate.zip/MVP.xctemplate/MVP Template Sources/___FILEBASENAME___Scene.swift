//  ___FILEHEADER___

import UIKit

final class ___FILEBASENAMEASIDENTIFIER___: BaseViewController {

    // MARK: - Variables
    private var viewModel: ___VARIABLE_productName___Contract.ViewModel?
    
    // MARK: - Life cycles
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}

extension ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_productName___Contract.View {
    func setViewModel(_ viewModel: ___VARIABLE_productName___Contract.ViewModel?) {
        self.viewModel = viewModel
    }
}

extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
