//  ___FILEHEADER___

import Foundation

final class ___FILEBASENAMEASIDENTIFIER___ {
    var navigator: ___VARIABLE_productName___Contract.Navigator?
    var useCase: ___VARIABLE_productName___Contract.UseCase?

    init(navigator: ___VARIABLE_productName___Contract.Navigator?,
         useCase: ___VARIABLE_productName___Contract.UseCase?) {
        self.navigator = navigator
        self.useCase = useCase
    }
}

extension ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_productName___Contract.ViewModel {
    
}
