//  ___FILEHEADER___

import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___ {
    typealias View = ___VARIABLE_productName___ViewProtocol
    typealias ViewModel = ___VARIABLE_productName___ViewModelProtocol
    typealias UseCase = ___VARIABLE_productName___UseCaseProtocol
    typealias Navigator = ___VARIABLE_productName___NavigatorProtocol
    typealias Builder = ___VARIABLE_productName___BuilderProtocol
}

protocol ___VARIABLE_productName___ViewProtocol {
    func setViewModel(_ viewModel: ___FILEBASENAMEASIDENTIFIER___.ViewModel?)
}

protocol ___VARIABLE_productName___ViewModelProtocol {
    var navigator: ___FILEBASENAMEASIDENTIFIER___.Navigator? { get set }
    var useCase: ___FILEBASENAMEASIDENTIFIER___.UseCase? { get set }
}

protocol ___VARIABLE_productName___UseCaseProtocol {
    
}

protocol ___VARIABLE_productName___NavigatorProtocol {
    
}

protocol ___VARIABLE_productName___BuilderProtocol {
    func build() -> ___VARIABLE_productName___Scene
    func build(viewController: UIViewController) -> ___FILEBASENAMEASIDENTIFIER___.ViewModel
    func build(viewController: UIViewController) -> ___FILEBASENAMEASIDENTIFIER___.Navigator
}
