//  ___FILEHEADER___

import Foundation

final class ___FILEBASENAMEASIDENTIFIER___ {
  
}

extension ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_productName___Contract.UseCase {
    
}
